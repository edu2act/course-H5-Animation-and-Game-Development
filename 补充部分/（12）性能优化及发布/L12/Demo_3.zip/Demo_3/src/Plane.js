/**
 * Created by qile on 15-11-12.
 */
var Plane = cc.Sprite.extend({
    ctor: function (fileName) {
        cc.log("ctor");
        this._super(fileName);
        this.schedule(this.shoot,0.1);

    },
  /*  update:function(){
        this.shoot();
    },*/
    shoot:function(){
        var bullet = Bullet.create(res.CloseNormal_png,cc.p(0,1280),this.getPosition());
        this.addChild(bullet,-1);
    }
});