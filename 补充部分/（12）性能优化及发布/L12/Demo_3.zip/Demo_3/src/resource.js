var res = {
    HelloWorld_png : "res/HelloWorld.png",
    CloseNormal_png : "res/CloseNormal.png",
    CloseSelected_png : "res/CloseSelected.png",

    p1_png : "res/p1.png",
    p2_png : "res/p2.png",
    bg1_jpg : "res/bg1.jpg",
    bg2_jpg : "res/bg2.jpg"
};

var g_resources = [];
for (var i in res) {
    g_resources.push(res[i]);
}