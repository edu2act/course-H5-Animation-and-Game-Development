/**
 * Created by qile on 15-11-12.
 */
var Bullet = cc.Sprite.extend({
    velocity:null,
    ctor: function (fileName,velocity) {
        this._super(fileName);
        this.velocity = velocity;
        this.setPosition(cc.p(100,30));
        this.scheduleUpdate();
    },
    update:function(dt){
        var size = cc.winSize;

        //设置位置
        this.x += this.velocity.x*0.01;
        this.y += this.velocity.y*0.01;

        if(this.y > size.height){
            cc.pool.putInPool(this);
        }
    },
    unuse:function(){   //unuse 当putInPool时自动调用
        this.retain();
        this.setVisible(false);
        this.unscheduleUpdate();
        this.removeFromParent();
    },
    reuse:function(spriteName,velocity){   //reuse 当getFromPool时自动调用
        this.spriteFrameName = spriteName;
        this.velocity = velocity;
        this.setVisible(true);
        this.setPosition(cc.p(100,30));
        this.scheduleUpdate();
    }
});
Bullet.create = function(spriteFrameName,velocity){
    if(cc.pool.hasObject(Bullet)){
        cc.log("已有-可以从Pool里获取");
        return cc.pool.getFromPool(Bullet,spriteFrameName,velocity);
    }else{
        cc.log("没有-需重新创建");
        var b = new Bullet(spriteFrameName,velocity);
        return b;
    }
};